^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package openslam_gmapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-06-25)
------------------
* fix cppcheck warnings
* License from BSD to CC
* Contributors: Isaac IY Saito, Vincent Rabaud

0.1.0 (2013-06-28 17:33:53 -0700)
---------------------------------
- Forked from https://openslam.informatik.uni-freiburg.de/data/svn/gmapping/trunk/
- Catkinized and prepared for release into the ROS ecosystem
